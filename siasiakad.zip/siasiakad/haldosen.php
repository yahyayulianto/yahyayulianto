<!DOCTYPE html>
<html>
<head>
 <title>Halaman Dosen</title>
</head>
<body>
 <?php
 session_start();
 ?>
 <h1>Ini Halaman Dosen</h1>

</body>
</html>