<!DOCTYPE html>
<html>
<head>
 <title>Halaman Siswa</title>
</head>
<body>
 <?php
 session_start();
 ?>
 <h1>Ini Halaman Siswa</h1>

</body>
</html>