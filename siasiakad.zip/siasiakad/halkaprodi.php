<!DOCTYPE html>
<html>
<head>
 <title>Halaman Kaprodi</title>
</head>
<body>
 <?php
 session_start();
 ?>
 <h1>Ini Halaman Kaprodi</h1>

</body>
</html>